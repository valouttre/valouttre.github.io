import os
import json
from constants import SAVE_DIR

def ensure_save_dir():
    if not os.path.exists(SAVE_DIR):
        os.makedirs(SAVE_DIR)

def sauvegarder_remappages_auto(remappages):
    with open("mappings.json", "w", encoding="utf-8") as f:
        json.dump(remappages, f, ensure_ascii=False, indent=2)

def charger_remappages_auto():
    remappages = {}
    if os.path.exists("mappings.json"):
        try:
            with open("mappings.json", "r", encoding="utf-8") as f:
                remappages = json.load(f)
        except json.JSONDecodeError:
            remappages = {}
    return remappages

def lister_saves():
    ensure_save_dir()
    return [f[:-5] for f in os.listdir(SAVE_DIR) if f.endswith(".json")]

def sauvegarder_remappages_fichier(remappages, nom):
    ensure_save_dir()
    chemin = os.path.join(SAVE_DIR, f"{nom}.json")
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(remappages, f, ensure_ascii=False, indent=2)

def charger_selection_save(nom):
    chemin = os.path.join(SAVE_DIR, f"{nom}.json")
    if os.path.exists(chemin):
        with open(chemin, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def supprimer_save_fichier(nom):
    chemin = os.path.join(SAVE_DIR, f"{nom}.json")
    if os.path.exists(chemin):
        os.remove(chemin)
