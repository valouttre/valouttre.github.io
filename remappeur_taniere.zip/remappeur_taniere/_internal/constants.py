from pynput.keyboard import Key
from pynput.mouse import Button

SAVE_DIR = "saves"

# Liste des touches et clics souris
toutes_les_touches = [
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
    '1','2','3','4','5','6','7','8','9','0',
    'space','enter','tab','backspace','shift','ctrl','alt','caps_lock','esc',
    'f1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12',
    'up','down','left','right','home','end','page_up','page_down','insert','delete',
    'left_click','right_click','middle_click','xbutton1','xbutton2'
]

# Mapping clavier pour pynput
pynput_keys_map = {
    'space': Key.space,
    'enter': Key.enter,
    'tab': Key.tab,
    'backspace': Key.backspace,
    'shift': Key.shift,
    'ctrl': Key.ctrl,
    'alt': Key.alt,
    'caps_lock': Key.caps_lock,
    'esc': Key.esc,
    'up': Key.up,
    'down': Key.down,
    'left': Key.left,
    'right': Key.right,
    'home': Key.home,
    'end': Key.end,
    'page_up': Key.page_up,
    'page_down': Key.page_down,
    'insert': Key.insert,
    'delete': Key.delete,
    'f1': Key.f1, 'f2': Key.f2, 'f3': Key.f3, 'f4': Key.f4, 'f5': Key.f5,
    'f6': Key.f6, 'f7': Key.f7, 'f8': Key.f8, 'f9': Key.f9, 'f10': Key.f10,
    'f11': Key.f11, 'f12': Key.f12
}

# Mapping souris
mouse_buttons_map = {
    'left_click': Button.left,
    'right_click': Button.right,
    'middle_click': Button.middle,
    'xbutton1': Button.x1,
    'xbutton2': Button.x2
}
