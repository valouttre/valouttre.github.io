from ui import RemapperApp

if __name__ == "__main__":
    app = RemapperApp()
    app.mainloop()
