import os
import json

def get_config_path():
    appdata = os.getenv('APPDATA')
    if appdata:
        path = os.path.join(appdata, "taniere")
    else:
        path = os.path.join(os.getcwd(), ".taniere")
    os.makedirs(path, exist_ok=True)
    return os.path.join(path, "config.json")

CONFIG_PATH = get_config_path()

def load_config():
    """Charge la config depuis le fichier JSON ou retourne {} si fichier absent"""
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_config(data):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
