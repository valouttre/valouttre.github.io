from pynput import mouse, keyboard
from pynput.keyboard import Key, KeyCode, Controller
import threading
import time
from mouse_control import send_mouse_click, send_mouse_move

# AZERTY mapping helpers
AZERTY_NUMERIC = {
    '1': '&', '2': 'é', '3': '"', '4': "'", '5': '(', '6': '-', '7': 'è', '8': '_', '9': 'ç', '0': 'à'
}
AZERTY_ALPHA_SWAPS = {}  # pas d'échange de touches alphabétiques

def map_to_azerty_char(char):
    if not isinstance(char, str) or len(char) == 0:
        return char
    if char in AZERTY_NUMERIC:
        return AZERTY_NUMERIC[char]
    lower = char.lower()
    if lower in AZERTY_ALPHA_SWAPS:
        mapped = AZERTY_ALPHA_SWAPS[lower]
        return mapped.upper() if char.isupper() else mapped
    return char


class MacroRecorder:
    def __init__(self):
        self.events = []
        self.recording = False
        self.playing = False
        self.loop_count = 1
        self.mouse_listener = None
        self.kb_listener = None
        self.global_stop_event = threading.Event()
        self.lock = threading.Lock()
        self.last_position = None
        self.keyboard_ctrl = Controller()

    def start_recording(self):
        with self.lock:
            if self.recording:
                return
            self.events.clear()
            self.recording = True
            self.start_time = time.time()
            self.global_stop_event.clear()
            self.last_position = None

        def on_click(x, y, button, pressed):
            with self.lock:
                if not self.recording:
                    return False
                self.events.append({
                    'type': 'mouse',
                    'event': 'click',
                    'x': x,
                    'y': y,
                    'button': str(button),
                    'pressed': pressed,
                    'timestamp': time.time() - self.start_time
                })

        def on_move(x, y):
            with self.lock:
                if not self.recording:
                    return False
                if self.last_position == (x, y):
                    return
                self.last_position = (x, y)
                self.events.append({
                    'type': 'mouse',
                    'event': 'move',
                    'x': x,
                    'y': y,
                    'timestamp': time.time() - self.start_time
                })

        def on_key_press(key):
            try:
                char = key.char if isinstance(key, KeyCode) else None
            except AttributeError:
                char = None
            azerty_char = map_to_azerty_char(char) if char else None
            with self.lock:
                self.events.append({
                    'type': 'key_press',
                    'timestamp': time.time() - self.start_time,
                    'key_repr': repr(key),
                    'char': char,
                    'azerty_char': azerty_char
                })

        def on_key_release(key):
            with self.lock:
                self.events.append({
                    'type': 'key_release',
                    'timestamp': time.time() - self.start_time,
                    'key_repr': repr(key)
                })

        self.mouse_listener = mouse.Listener(on_click=on_click, on_move=on_move)
        self.kb_listener = keyboard.Listener(on_press=on_key_press, on_release=on_key_release)
        self.mouse_listener.start()
        self.kb_listener.start()

    def stop_recording(self):
        with self.lock:
            self.recording = False
        if self.mouse_listener:
            self.mouse_listener.stop()
            self.mouse_listener = None
        if self.kb_listener:
            self.kb_listener.stop()
            self.kb_listener = None

    def play(self, loop=False, blocking=False, on_loop_end=None):
        with self.lock:
            if self.playing or not self.events:
                return
            self.loop_count = 999999 if loop else 1
            self.playing = True
            self.global_stop_event.clear()
            events_copy = self.events[:]

        def play_events():
            for _ in range(self.loop_count):
                last_timestamp = 0
                for event in events_copy:
                    if self.global_stop_event.is_set():
                        with self.lock:
                            self.playing = False
                        return

                    delay = event['timestamp'] - last_timestamp
                    if delay > 0:
                        time.sleep(delay)

                    if event['type'] == 'mouse':
                        if event['event'] == 'move':
                            send_mouse_move(event['x'], event['y'])
                        elif event['event'] == 'click':
                            send_mouse_click(event['button'], event['pressed'])

                    elif event['type'] == 'key_press':
                        if event.get('azerty_char') is not None:
                            self.keyboard_ctrl.press(event['azerty_char'])
                        elif event.get('char') is not None:
                            self.keyboard_ctrl.press(event['char'])
                        else:
                            try:
                                key_obj = eval(event['key_repr'], {'Key': Key})
                                self.keyboard_ctrl.press(key_obj)
                            except Exception:
                                pass

                    elif event['type'] == 'key_release':
                        if event.get('azerty_char') is not None:
                            self.keyboard_ctrl.release(event['azerty_char'])
                        elif event.get('char') is not None:
                            self.keyboard_ctrl.release(event['char'])
                        else:
                            try:
                                key_obj = eval(event['key_repr'], {'Key': Key})
                                self.keyboard_ctrl.release(key_obj)
                            except Exception:
                                pass

                    last_timestamp = event['timestamp']

                if on_loop_end:
                    on_loop_end()

            with self.lock:
                self.playing = False

        if blocking:
            play_events()
        else:
            threading.Thread(target=play_events, daemon=True).start()

    def stop_playing(self):
        self.global_stop_event.set()

    # ---------------- SAVE / LOAD ----------------
    def save(self, path):
        import json
        data_to_save = self.events[:]
        # Calcul durée entre premier et dernier événement
        if self.events:
            duration = self.events[-1]['timestamp'] - self.events[0]['timestamp']
            if duration < 0:
                duration = self.events[-1]['timestamp']
        else:
            duration = 0
        # Ajoute un objet spécial pour durée
        data_to_save.append({"__duration__": duration})
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data_to_save, f, indent=2, ensure_ascii=False)

    def load(self, path):
        import json
        with open(path, 'r', encoding='utf-8') as f:
            loaded = json.load(f)
        # Filtre la durée si présente
        if loaded and isinstance(loaded[-1], dict) and "__duration__" in loaded[-1]:
            self.duration = loaded[-1]["__duration__"]
            self.events = loaded[:-1]
        else:
            self.duration = None
            self.events = loaded

    def get_duration(self):
        # Si la durée a été chargée depuis fichier
        if hasattr(self, 'duration') and self.duration is not None:
            return self.duration
        # Sinon calcul à partir des events
        if not self.events:
            return 0
        return self.events[-1]['timestamp'] - self.events[0]['timestamp']
