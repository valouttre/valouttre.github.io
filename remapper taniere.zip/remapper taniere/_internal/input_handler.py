import keyboard as kb
from pynput.keyboard import Controller as KeyboardController
from pynput.mouse import Controller as MouseController, Listener as MouseListener
from constants import pynput_keys_map, mouse_buttons_map

keyboard_controller = KeyboardController()
mouse = MouseController()

class InputHandler:
    def __init__(self, remappages):
        self.remappages = remappages
        self.running = False
        self.listener_mouse = None
        self.keyboard_hook = None

    def set_remappages(self, remappages):
        self.remappages = remappages

    def simuler_touche_presser(self, touche):
        if touche in pynput_keys_map:
            keyboard_controller.press(pynput_keys_map[touche])
        elif len(touche) == 1:
            keyboard_controller.press(touche)
        elif touche in mouse_buttons_map:
            mouse.press(mouse_buttons_map[touche])

    def simuler_touche_relacher(self, touche):
        if touche in pynput_keys_map:
            keyboard_controller.release(pynput_keys_map[touche])
        elif len(touche) == 1:
            keyboard_controller.release(touche)
        elif touche in mouse_buttons_map:
            mouse.release(mouse_buttons_map[touche])

    def start(self):
        if self.running:
            return
        self.running = True
        self.listener_mouse = MouseListener(on_click=self.on_click)
        self.listener_mouse.start()

        def on_keyboard_event(event):
            if event.name in self.remappages:
                replacement = self.remappages[event.name]
                if event.event_type == 'down':
                    self.simuler_touche_presser(replacement)
                elif event.event_type == 'up':
                    self.simuler_touche_relacher(replacement)
                return False
            return True

        self.keyboard_hook = kb.hook(on_keyboard_event)

    def stop(self):
        if not self.running:
            return
        self.running = False
        if self.listener_mouse:
            self.listener_mouse.stop()
            self.listener_mouse = None
        if self.keyboard_hook:
            kb.unhook(self.keyboard_hook)
            self.keyboard_hook = None

    def toggle(self):
        if self.running:
            self.stop()
        else:
            self.start()
        return self.running

    def on_click(self, x, y, button, pressed):
        for origine, remplacement in self.remappages.items():
            if origine in mouse_buttons_map and mouse_buttons_map[origine] == button:
                if pressed:
                    self.simuler_touche_presser(remplacement)
                else:
                    self.simuler_touche_relacher(remplacement)
