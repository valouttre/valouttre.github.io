import os
import ttkbootstrap as tb
from tkinter import messagebox, Listbox
from ttkbootstrap.constants import *
from constants import toutes_les_touches, SAVE_DIR
import mappings
from input_handler import InputHandler

ORANGE = "#FF8C42"
BG_DARK = "#1E1E1E"
PANEL = "#232323"

class RemapperApp(tb.Window):
    def __init__(self):
        super().__init__(themename="darkly")
        self.title("Remappeur de Touches - Refonte")
        self.geometry("820x620")
        self.minsize(720, 520)
        self.configure(background=BG_DARK)

        # Styles globaux
        style = tb.Style()
        style.configure("TFrame", background=BG_DARK)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Title.TLabel", font=("Segoe UI", 14, "bold"), foreground=ORANGE, background=BG_DARK)
        style.configure("Small.TLabel", font=("Segoe UI", 10), foreground=ORANGE, background=BG_DARK)
        style.configure("TLabel", foreground=ORANGE, background=BG_DARK)
        style.configure("TButton", foreground=ORANGE)
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))
        style.configure("Toggle.TButton", font=("Segoe UI", 11, "bold"), padding=10)
        style.map("Toggle.TButton",
                  foreground=[("!disabled", "white")])

        # État & handlers
        self.remappages = mappings.charger_remappages_auto()
        self.handler = InputHandler(self.remappages)

        if not os.path.exists(SAVE_DIR):
            os.makedirs(SAVE_DIR)

        # --- Layout principal
        self.topbar = tb.Frame(self, style="Panel.TFrame", padding=10)
        self.topbar.pack(side="top", fill="x")

        self.center = tb.Frame(self, padding=10)
        self.center.pack(side="top", fill="both", expand=True)

        self.bottombar = tb.Frame(self, style="Panel.TFrame", padding=10)
        self.bottombar.pack(side="bottom", fill="x")

        self._build_topbar()
        self._build_center()
        self._build_bottombar()
        self._refresh_saves()
        self._refresh_list()
        self._refresh_toggle_visual()

    # ---------- UI Builders ----------
    def _build_topbar(self):
        tb.Label(self.topbar, text="Remappeur taniere", style="Title.TLabel").pack(side="left")

        right = tb.Frame(self.topbar, style="Panel.TFrame")
        right.pack(side="right")

        self.origine_combo = tb.Combobox(right, values=toutes_les_touches, width=18, bootstyle="dark")
        self.origine_combo.pack(side="left", padx=(0,6))
        self.origine_combo.insert(0, "touche origine")

        self.remplacement_combo = tb.Combobox(right, values=toutes_les_touches, width=20, bootstyle="dark")
        self.remplacement_combo.pack(side="left", padx=(0,6))
        self.remplacement_combo.insert(0, "touche remplacement")

        self.btn_add = tb.Button(right, text="➕ Ajouter", command=self.ajouter_remappage,
                                 bootstyle="secondary", style="Accent.TButton")
        self.btn_add.pack(side="left")

    def _build_center(self):
        list_frame = tb.Frame(self.center, style="Panel.TFrame", padding=10)
        list_frame.pack(fill="both", expand=True)

        tb.Label(list_frame, text="Remappages", style="Small.TLabel").pack(anchor="w", pady=(0,6))

        self.sequence_list = Listbox(list_frame, font=("Consolas", 10),
                                     selectmode="extended", activestyle="none",
                                     bg="#2A2A2A", fg=ORANGE)
        self.sequence_list.pack(fill="both", expand=True)

        actions = tb.Frame(list_frame, style="Panel.TFrame")
        actions.pack(fill="x", pady=(8,0))
        tb.Button(actions, text="🗑 Supprimer sélection", command=self.supprimer_remappage,
                  bootstyle="secondary").pack(side="left")
        tb.Button(actions, text="❌ Tout effacer", command=self.supprimer_tout,
                  bootstyle="secondary").pack(side="left", padx=6)

    def _build_bottombar(self):
        save_frame = tb.Frame(self.bottombar, style="Panel.TFrame")
        save_frame.pack(side="left", fill="x", expand=True)

        tb.Label(save_frame, text="Sauvegardes", style="Small.TLabel").pack(anchor="w")

        row = tb.Frame(save_frame, style="Panel.TFrame")
        row.pack(fill="x")

        self.save_combo = tb.Combobox(row, values=[], width=24, bootstyle="dark")
        self.save_combo.pack(side="left", padx=(0,6))
        self.save_combo.bind("<<ComboboxSelected>>", self.charger_selection_save)

        self.entry_save_name = tb.Entry(row, width=20, bootstyle="dark")
        self.entry_save_name.pack(side="left", padx=(0,6))
        self.entry_save_name.insert(0, "nom_sauvegarde")

        tb.Button(row, text="💾 Sauver", command=self.sauvegarder_remappages_fichier,
                  bootstyle="secondary").pack(side="left", padx=(0,6))
        tb.Button(row, text="🗑 Suppr.", command=self.supprimer_save_fichier,
                  bootstyle="secondary").pack(side="left")

        self.toggle_btn = tb.Button(self.bottombar, text="⏹️ Arrêté",
                                    command=self.on_toggle,
                                    bootstyle="danger",
                                    style="Toggle.TButton")
        self.toggle_btn.pack(side="right")

    # ---------- Actions ----------
    def ajouter_remappage(self):
        origine = self.origine_combo.get().strip()
        remplacement = self.remplacement_combo.get().strip()
        if not origine or not remplacement or origine == "touche origine" or remplacement == "touche remplacement":
            messagebox.showwarning("Champs manquants", "Veuillez choisir les deux touches.")
            return
        if origine in self.remappages:
            messagebox.showwarning("Doublon", f"La touche '{origine}' est déjà remappée.")
            return
        self.remappages[origine] = remplacement
        self.handler.set_remappages(self.remappages)
        mappings.sauvegarder_remappages_auto(self.remappages)
        self._refresh_list()
        self.origine_combo.set("")
        self.remplacement_combo.set("")

    def supprimer_remappage(self):
        selected = self.sequence_list.curselection()
        for idx in reversed(selected):
            origine = self.sequence_list.get(idx).split(" → ")[0]
            if origine in self.remappages:
                del self.remappages[origine]
            self.sequence_list.delete(idx)
        self.handler.set_remappages(self.remappages)
        mappings.sauvegarder_remappages_auto(self.remappages)

    def supprimer_tout(self):
        if messagebox.askyesno("Confirmation", "Supprimer tous les remappages ?"):
            self.remappages.clear()
            self._refresh_list()
            self.handler.set_remappages(self.remappages)
            mappings.sauvegarder_remappages_auto(self.remappages)

    def sauvegarder_remappages_fichier(self):
        nom = self.entry_save_name.get().strip()
        if not nom or nom == "nom_sauvegarde":
            messagebox.showwarning("Nom manquant", "Veuillez entrer un nom.")
            return
        mappings.sauvegarder_remappages_fichier(self.remappages, nom)
        self._refresh_saves()
        self.save_combo.set(nom)

    def charger_selection_save(self, event=None):
        nom = self.save_combo.get().strip()
        if not nom:
            return
        self.remappages = mappings.charger_selection_save(nom)
        self.handler.set_remappages(self.remappages)
        mappings.sauvegarder_remappages_auto(self.remappages)
        self._refresh_list()

    def supprimer_save_fichier(self):
        nom = self.save_combo.get().strip()
        if not nom:
            messagebox.showinfo("Info", "Choisissez une sauvegarde à supprimer.")
            return
        mappings.supprimer_save_fichier(nom)
        self._refresh_saves()
        self.save_combo.set("")

    def on_toggle(self):
        running = self.handler.toggle()
        self._refresh_toggle_visual(running)

    # ---------- Helpers UI ----------
    def _refresh_list(self):
        self.sequence_list.delete(0, "end")
        for origine, remplacement in self.remappages.items():
            self.sequence_list.insert("end", f"{origine} → {remplacement}")

    def _refresh_saves(self):
        saves = mappings.lister_saves()
        self.save_combo.configure(values=saves)

    def _refresh_toggle_visual(self, running=None):
        if running is None:
            running = self.handler.running
        if running:
            self.toggle_btn.configure(text="Stop", bootstyle="danger")
        else:
            self.toggle_btn.configure(text="Start", bootstyle="success")
